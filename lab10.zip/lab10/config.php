<?php
define('DBHOST', 'localhost');
define('DBNAME', 'art');
define('DBUSER', 'testuser');
define('DBPASS', 'ybk553265880');
define('DBCONNSTRING','mysql:dbname=art;charset=utf8mb4;');
?>